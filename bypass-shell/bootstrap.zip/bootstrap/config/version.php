<?php
define('KOD_VERSION','4.52');
define('KOD_VERSION_BUILD','01');//time(),20231212