<?php exit;?>{
    "fontSize": "14px",
    "theme": "tomorrow",
    "autoWrap": 1,
    "autoComplete": 1,
    "functionList": 1,
    "tabSize": 4,
    "softTab": 1,
    "displayChar": 0,
    "fontFamily": "Menlo",
    "keyboardType": "ace",
    "autoSave": 0
}