<?php exit;?>{
    "listType": "icon",
    "listSortField": "name",
    "listSortOrder": "up",
    "fileIconSize": "80",
    "animateOpen": "1",
    "soundOpen": "0",
    "theme": "win10",
    "wall": "8",
    "fileRepeat": "replace",
    "recycleOpen": "1",
    "resizeConfig": "{\"filename\":250,\"filetype\":80,\"filesize\":80,\"filetime\":215,\"editorTreeWidth\":200,\"explorerTreeWidth\":200}"
}