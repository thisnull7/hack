<?php exit;?>{
    "1": {
        "name": "admin",
        "path": "admin",
        "password": "d3da205fae0b78b332216ad3e7935229",
        "userID": "1",
        "role": "1",
        "config": {
            "sizeMax": "0",
            "sizeUse": 1024
        },
        "groupInfo": {
            "1": "write"
        },
        "createTime": 1729092182,
        "status": 1,
        "lastLogin": 1729596408
    },
    "100": {
        "userID": "100",
        "name": "demo",
        "password": "fe01ce2a7fbac8fafaed7c982a04e229",
        "role": "2",
        "config": {
            "sizeMax": 5,
            "sizeUse": 1048576
        },
        "groupInfo": {
            "1": "write"
        },
        "path": "demo",
        "status": 1,
        "lastLogin": "",
        "createTime": 1729092182
    },
    "101": {
        "userID": "101",
        "name": "guest",
        "password": "084e0343a0486ff05530df6c705c8bb4",
        "role": "100",
        "config": {
            "sizeMax": 0.1,
            "sizeUse": 1048576
        },
        "groupInfo": {
            "1": "read"
        },
        "path": "guest",
        "status": 1,
        "lastLogin": "",
        "createTime": 1729092182
    }
}