import time
import settings as cfg

class Trader:
    def __init__(self, wallet, jupiter):
        self.wallet = wallet
        self.jupiter = jupiter
        print("Trader ready")

    def buy(self, token_mint, decimals, symbol):
        amount_lamports = int(cfg.BUY_AMOUNT_SOL * 1e9)
        print(f"   {cfg.BUY_AMOUNT_SOL} SOL -> {symbol}")
        out_amount, sig = self.jupiter.execute_swap(cfg.SOL_MINT, token_mint, amount_lamports, cfg.SLIPPAGE_BPS, self.wallet)
        if sig:
            out_tokens = int(out_amount) / 10**decimals if out_amount else 0
            buy_price = cfg.BUY_AMOUNT_SOL / out_tokens if out_tokens > 0 else 0
            print(f"   BELI! {out_tokens:.6f} token")
            return buy_price
        print(f"   Gagal beli")
        return None

    def sell(self, token_mint, decimals, symbol):
        amt = self.wallet.get_token_balance(token_mint)
        if amt == 0:
            return None
        print(f"   Jual {amt/10**decimals:.6f} {symbol}")
        out_amount, sig = self.jupiter.execute_swap(token_mint, cfg.SOL_MINT, amt, cfg.SLIPPAGE_BPS, self.wallet)
        if sig:
            sol_out = int(out_amount) / 1e9 if out_amount else 0
            print(f"   JUAL! +{sol_out:.6f} SOL")
            return sol_out
        return None