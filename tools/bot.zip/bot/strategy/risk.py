import settings as cfg

class RiskManager:
    def __init__(self):
        print("Risk Manager ready")

    def can_open_position(self, active_positions, sol_balance):
        if active_positions >= cfg.MAX_POSITIONS:
            return False
        if sol_balance < cfg.BUY_AMOUNT_SOL:
            return False
        return True

    def should_take_profit(self, buy_price, current_price):
        if buy_price <= 0 or current_price <= 0:
            return False, 0
        pct_change = ((current_price - buy_price) / buy_price) * 100
        if pct_change >= cfg.TARGET_PROFIT_PCT:
            return True, pct_change
        if pct_change <= cfg.STOP_LOSS_PCT:
            return True, pct_change
        return False, pct_change