import requests, time, logging
import settings as cfg

logger = logging.getLogger(__name__)

class JupiterAPI:
    def __init__(self):
        self.headers = {"x-api-key": cfg.JUPITER_API_KEY}
        print("Jupiter API ready")

    def _retry_request(self, method, url, params=None, json_data=None, max_retries=cfg.RETRY_MAX):
        for attempt in range(max_retries):
            try:
                if method == "GET":
                    r = requests.get(url, params=params, headers=self.headers, timeout=15)
                else:
                    r = requests.post(url, json=json_data, headers=self.headers, timeout=15)
                if r.status_code == 200:
                    return r.json()
            except:
                pass
            time.sleep(cfg.RETRY_DELAY * (attempt + 1))
        return None

    def get_quote(self, input_mint, output_mint, amount, slippage_bps=cfg.SLIPPAGE_BPS):
        params = {"inputMint": input_mint, "outputMint": output_mint, "amount": str(amount), "slippageBps": str(slippage_bps)}
        return self._retry_request("GET", cfg.JUPITER_QUOTE_API, params=params)

    def get_swap_transaction(self, quote_response, user_pubkey):
        payload = {
            "quoteResponse": quote_response,
            "userPublicKey": user_pubkey,
            "wrapAndUnwrapSol": True,
            "dynamicComputeUnitLimit": True,
            "prioritizationFeeLamports": cfg.PRIORITY_FEE_LAMPORTS
        }
        return self._retry_request("POST", cfg.JUPITER_SWAP_API, json_data=payload)

    def get_prices(self, mints):
        ids = ",".join(mints)
        try:
            r = requests.get(cfg.JUPITER_PRICE_API, params={"ids": ids}, headers=self.headers, timeout=10)
            if r.status_code == 200:
                return r.json()
        except:
            pass
        return {}

    def get_token_price_sol(self, token_mint):
        data = self.get_prices([cfg.SOL_MINT, token_mint])
        sol_price = float(data.get(cfg.SOL_MINT, {}).get("usdPrice", 0))
        token_price = float(data.get(token_mint, {}).get("usdPrice", 0))
        if sol_price > 0 and token_price > 0:
            return token_price / sol_price
        return 0

    def execute_swap(self, input_mint, output_mint, amount, slippage_bps, wallet_manager):
        print("   [QUOTE] Getting quote...")
        quote = self.get_quote(input_mint, output_mint, amount, slippage_bps)
        if not quote:
            print("   [FAIL] Quote failed")
            return None, None
        
        out_amount = quote.get("outAmount", "0")
        
        # Cek apakah quote sudah mengandung transaksi
        tx_b64 = quote.get("swapTransaction") or quote.get("transaction")
        if tx_b64:
            print("   [SIGN] Direct TX from quote...")
            sig = wallet_manager.sign_and_send_transaction(tx_b64)
            if sig:
                print(f"   [OK] TX: {sig[:32]}...")
                return out_amount, sig
        
        # Minta swap transaction terpisah
        print("   [SWAP] Getting swap transaction...")
        swap_data = self.get_swap_transaction(quote, wallet_manager.pubkey_str)
        if swap_data:
            tx_b64 = swap_data.get("swapTransaction") or swap_data.get("transaction")
            if tx_b64:
                print("   [SIGN] Signing swap TX...")
                sig = wallet_manager.sign_and_send_transaction(tx_b64)
                if sig:
                    print(f"   [OK] TX: {sig[:32]}...")
                    return out_amount, sig
        
        print("   [FAIL] No valid transaction found")
        return None, None