import requests, time, logging
import settings as cfg

logger = logging.getLogger(__name__)

class DexScreenerScanner:
    def __init__(self):
        print("DexScreener ready")

    def fetch_solana_tokens(self, seen_tokens):
        tokens = []
        try:
            r = requests.get(cfg.DEXSCREENER_API, timeout=15)
            if r.status_code != 200:
                return []
            now = time.time() * 1000
            for item in r.json():
                if item.get("chainId") != "solana":
                    continue
                token_addr = item.get("tokenAddress", "")
                if not token_addr or token_addr in seen_tokens:
                    continue
                url_str = item.get("url", "")
                pair_addr = url_str.split("/")[-1] if "/" in url_str else token_addr
                symbol = item.get("symbol", token_addr[:8])
                updated = item.get("updatedAt", "")
                age_sec = 0
                if updated:
                    try:
                        ts = int(time.mktime(time.strptime(updated[:19], "%Y-%m-%dT%H:%M:%S"))) * 1000
                        age_sec = (now - ts) / 1000
                    except:
                        pass
                tokens.append({"pair": pair_addr, "token": token_addr, "symbol": symbol, "decimals": 6, "age_sec": age_sec, "url": url_str})
            tokens.sort(key=lambda x: x["age_sec"])
            return tokens
        except Exception as e:
            logger.error(f"DexScreener error: {e}")
            return []