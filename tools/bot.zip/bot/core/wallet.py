import base64, struct, json, os
from solana.rpc.api import Client
from solana.rpc.types import TxOpts
from solana.keypair import Keypair
from solana.publickey import PublicKey
from solana.transaction import VersionedTransaction
import settings as cfg

class WalletManager:
    def __init__(self):
        self.wallet = Keypair.from_base58_string(cfg.PRIVATE_KEY_BASE58)
        self.pubkey_str = str(self.wallet.public_key)
        self.client = Client(cfg.RPC_URL)
        print(f"Wallet: {self.pubkey_str}")

    def get_sol_balance(self):
        try:
            return self.client.get_balance(self.wallet.public_key).value / 1e9
        except:
            return 0.0

    def get_token_balance(self, mint):
        try:
            resp = self.client.get_token_accounts_by_owner(
                self.wallet.public_key, 
                {"mint": PublicKey(mint)}
            )
            for acc in resp.value:
                raw = bytes(acc.account.data)
                if len(raw) >= 72:
                    return struct.unpack_from("<Q", raw, 64)[0]
        except:
            pass
        return 0

    def sign_and_send_transaction(self, tx_base64):
        try:
            tx_bytes = base64.b64decode(tx_base64)
            txn = VersionedTransaction.deserialize(tx_bytes)
            
            # Sign transaksi - cara yang benar di Linux
            txn.sign([self.wallet])
            
            # Kirim
            result = self.client.send_transaction(
                txn, 
                TxOpts(skip_preflight=True, max_retries=5)
            )
            return str(result.value)
            
        except Exception as e:
            print(f"   TX Error: {str(e)[:150]}")
            return None

    def load_positions(self):
        try:
            with open(cfg.POSITIONS_FILE) as f:
                return json.load(f)
        except:
            return {}

    def save_positions(self, positions):
        os.makedirs(os.path.dirname(cfg.POSITIONS_FILE), exist_ok=True)
        with open(cfg.POSITIONS_FILE, "w") as f:
            json.dump(positions, f, indent=2)

    def load_history(self):
        try:
            with open(cfg.HISTORY_FILE) as f:
                return json.load(f)
        except:
            return []

    def save_history(self, history):
        os.makedirs(os.path.dirname(cfg.HISTORY_FILE), exist_ok=True)
        with open(cfg.HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=2)