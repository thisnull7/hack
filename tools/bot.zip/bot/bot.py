#!/usr/bin/env python3
import time, json, os, sys, logging
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import settings as cfg

import importlib.util

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

wallet_mod = load_module("wallet", os.path.join(BASE_DIR, "core", "wallet.py"))
jupiter_mod = load_module("jupiter", os.path.join(BASE_DIR, "core", "jupiter.py"))
dexscreener_mod = load_module("dexscreener", os.path.join(BASE_DIR, "core", "dexscreener.py"))
trader_mod = load_module("trader", os.path.join(BASE_DIR, "strategy", "trader.py"))
risk_mod = load_module("risk", os.path.join(BASE_DIR, "strategy", "risk.py"))

WalletManager = wallet_mod.WalletManager
JupiterAPI = jupiter_mod.JupiterAPI
DexScreenerScanner = dexscreener_mod.DexScreenerScanner
Trader = trader_mod.Trader
RiskManager = risk_mod.RiskManager

os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(cfg.LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AutoTradeBot:
    def __init__(self):
        logger.info("=" * 60)
        logger.info("[BOT] AUTO TRADE SOLANA")
        logger.info("=" * 60)
        
        self.wallet = WalletManager()
        self.jupiter = JupiterAPI()
        self.scanner = DexScreenerScanner()
        self.trader = Trader(self.wallet, self.jupiter)
        self.risk = RiskManager()
        
        self.positions = self.wallet.load_positions()
        self.history = self.wallet.load_history()
        self.seen_tokens = set()
        self.owned_tokens = set()
        
        for p in self.positions.values():
            self.seen_tokens.add(p["token"])
            if not p.get("sold"):
                self.owned_tokens.add(p["token"])
        
        self.total_bought = len(self.positions)
        self.total_sold = len([p for p in self.positions.values() if p.get("sold")])
        self.total_profit_sol = sum(p.get("profit_sol", 0) for p in self.positions.values() if p.get("sold"))
        
        logger.info(f"[WALLET] {self.wallet.pubkey_str}")
        logger.info(f"[SOL] Modal: {cfg.BUY_AMOUNT_SOL} SOL | TP: {cfg.TARGET_PROFIT_PCT}%% | SL: {cfg.STOP_LOSS_PCT}%%")
        logger.info(f"[STATS] Posisi: {len(self.owned_tokens)} aktif | History: {len(self.history)}")
    
    def save_state(self):
        self.wallet.save_positions(self.positions)
        self.wallet.save_history(self.history)
    
    def run_diagnostics(self):
        logger.info("\n[DIAG] Diagnostik...")
        sol = self.wallet.get_sol_balance()
        logger.info(f"   Wallet: [{'OK' if sol > 0 else 'FAIL'}] ({sol:.4f} SOL)")
        
        test_q = self.jupiter.get_quote(cfg.SOL_MINT, cfg.USDC_MINT, 1000000, 100)
        if test_q:
            logger.info(f"   Jupiter Quote: [OK]")
            test_s = self.jupiter.get_swap_transaction(test_q, self.wallet.pubkey_str)
            logger.info(f"   Swap API: [{'OK' if test_s else 'FAIL'}]")
        else:
            logger.info(f"   Jupiter Quote: [FAIL]")
        
        tokens = self.scanner.fetch_solana_tokens(set())
        logger.info(f"   DexScreener: [{'OK' if tokens else 'FAIL'}] ({len(tokens)} token)")
        logger.info(f"\n[SOL] Saldo: {sol:.4f} SOL")
        logger.info(f"[STATS] Profit Total: {self.total_profit_sol:.6f} SOL")
        logger.info("=" * 60)
    
    def run(self):
        self.run_diagnostics()
        cycle = 0
        
        while True:
            try:
                cycle += 1
                sol = self.wallet.get_sol_balance()
                active = len([p for p in self.positions.values() if not p.get("sold")])
                
                tokens = self.scanner.fetch_solana_tokens(self.seen_tokens)
                fresh = [t for t in tokens if t["token"] not in self.owned_tokens]
                
                logger.info(f"\n{'='*60}")
                logger.info(f">> Siklus #{cycle} | SOL: {sol:.4f} | Posisi: {active}/{cfg.MAX_POSITIONS}")
                logger.info(f"[SCAN] Token baru: {len(fresh)}")
                
                for i, t in enumerate(fresh[:5]):
                    logger.info(f"   [{i+1}] [NEW] {t['symbol'][:12]:12s} | {t['age_sec']:.0f}s")
                
                # AUTO BUY
                if self.risk.can_open_position(active, sol) and fresh:
                    t = fresh[0]
                    logger.info(f"\n[BUY] AUTO-BUY: {t['symbol']}")
                    logger.info(f"   Umur: {t['age_sec']:.0f}s | Token: {t['token']}")
                    
                    bp = self.trader.buy(t["token"], t["decimals"], t["symbol"])
                    if bp:
                        self.positions[t["pair"]] = {
                            "token": t["token"],
                            "symbol": t["symbol"],
                            "invested_sol": cfg.BUY_AMOUNT_SOL,
                            "buy_price_sol": bp,
                            "decimals": t["decimals"],
                            "sold": False,
                            "time_open": time.time(),
                            "date_open": datetime.now().isoformat()
                        }
                        self.owned_tokens.add(t["token"])
                        self.seen_tokens.add(t["token"])
                        self.total_bought += 1
                        self.save_state()
                        logger.info(f"   [STATS] Total dibeli: {self.total_bought}")
                    time.sleep(3)
                
                # AUTO SELL
                for pos_id, pos in list(self.positions.items()):
                    if pos.get("sold"):
                        continue
                    
                    cp = self.jupiter.get_token_price_sol(pos["token"])
                    if cp == 0:
                        q = self.jupiter.get_quote(pos["token"], cfg.SOL_MINT, 10**pos["decimals"], 100)
                        if q:
                            cp = int(q.get("outAmount", 0)) / 1e9
                    
                    if cp > 0 and pos["buy_price_sol"] > 0:
                        should_exit, pct = self.risk.should_take_profit(pos["buy_price_sol"], cp)
                        
                        if pct > 30 or pct < -20:
                            direction = "[UP]" if pct > 0 else "[DOWN]"
                            logger.info(f"{direction} {pos['symbol']}: {pct:+.1f}%% | {cp:.8f} SOL | Hold: {(time.time()-pos['time_open'])/60:.1f}m")
                        
                        if should_exit:
                            reason = "TAKE PROFIT" if pct > 0 else "STOP LOSS"
                            logger.info(f"\n{'='*60}")
                            logger.info(f"[TP] {reason}! {pos['symbol']} | {pct:+.1f}%%")
                            logger.info(f"   Beli: {pos['buy_price_sol']:.8f} SOL | Now: {cp:.8f} SOL")
                            logger.info(f"   Hold: {(time.time()-pos['time_open'])/60:.1f} menit")
                            logger.info(f"{'='*60}")
                            
                            out = self.trader.sell(pos["token"], pos["decimals"], pos["symbol"])
                            if out:
                                pos["sold"] = True
                                pos["sol_received"] = out
                                pos["profit_sol"] = out - pos["invested_sol"]
                                pos["profit_pct"] = pct
                                pos["time_close"] = time.time()
                                pos["date_close"] = datetime.now().isoformat()
                                pos["exit_reason"] = reason
                                
                                self.owned_tokens.discard(pos["token"])
                                self.total_sold += 1
                                self.total_profit_sol += pos["profit_sol"]
                                self.history.append(pos)
                                self.save_state()
                                logger.info(f"   [SOL] Profit: {pos['profit_sol']:.6f} SOL")
                                logger.info(f"   [STATS] Total Profit: {self.total_profit_sol:.6f} SOL")
                                break
                    time.sleep(0.3)
                
                if self.total_sold > 0:
                    logger.info(f"\n[STATS] {self.total_bought} bought | {self.total_sold} sold | Profit: {self.total_profit_sol:.6f} SOL")
                
                time.sleep(cfg.CHECK_INTERVAL_SEC)
                
            except KeyboardInterrupt:
                logger.info(f"\n\n[STOP] Bot dihentikan manual.")
                logger.info(f"[STATS] Final: {self.total_bought} bought | {self.total_sold} sold | Profit: {self.total_profit_sol:.6f} SOL")
                break
            except Exception as e:
                logger.error(f"[ERROR] {e}")
                import traceback
                logger.error(traceback.format_exc())
                time.sleep(5)

if __name__ == "__main__":
    bot = AutoTradeBot()
    bot.run()