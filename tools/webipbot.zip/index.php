<?php
session_start();

// Cek jika sudah login, redirect ke dashboard
if(isset($_SESSION['user'])) {  // Ubah dari $_SESSION['login'] ke $_SESSION['user']
    header("Location: dashboard.php");
    exit();
}

// Konfigurasi login
$valid_username = "admin";
$valid_password = "null1337";

$error_msg = "";
$username = "";

// Proses login
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if($username === $valid_username && $password === $valid_password) {
        // Set session dengan nama yang konsisten
        $_SESSION['user'] = $username;  // Simpan sebagai 'user'
        $_SESSION['pass'] = $password;  // Simpan juga password jika perlu
        
        header("Location: dashboard.php");
        exit();
    } else {
        $error_msg = "Invalid credentials. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>0xA Panel | Secure Login</title>
    <link rel="stylesheet" href="assets/login-style.css">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel='stylesheet'>
</head>
<body>
    <!-- Background -->
    <div class="background-container">
        <div class="gradient-bg"></div>
        <div class="floating-shapes">
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
            <div class="shape"></div>
        </div>
    </div>

    <!-- Login Container -->
    <div class="login-container">
        <div class="login-card">
            <!-- Logo -->
            <div class="logo-section">
                <div class="logo">
                    <i class='bx bx-lock-alt'></i>
                </div>
                <h1>Secure Access</h1>
                <p>Enter your credentials to access the admin panel</p>
            </div>

            <!-- Error Message -->
            <?php if($error_msg): ?>
            <div class="error-message">
                <i class='bx bx-error-circle'></i>
                <span><?php echo $error_msg; ?></span>
            </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST" action="" class="login-form" id="loginForm">
                <!-- Username -->
                <div class="input-group">
                    <label for="username">Username</label>
                    <div class="input-field">
                        <input type="text" id="username" name="username" 
                               placeholder="Enter username" required 
                               value="<?php echo htmlspecialchars($username); ?>">
                        <i class='bx bx-user input-icon'></i>
                    </div>
                </div>

                <!-- Password -->
                <div class="input-group">
                    <label for="password">Password</label>
                    <div class="input-field">
                        <input type="password" id="password" name="password" 
                               placeholder="Enter password" required>
                        <i class='bx bx-key input-icon'></i>
                        <button type="button" class="toggle-password" id="togglePassword">
                            <i class='bx bx-show'></i>
                        </button>
                    </div>
                </div>

                <!-- Submit -->
                <button type="submit" class="submit-btn">
                    <i class='bx bx-log-in'></i> Sign In
                </button>
            </form>

            <!-- Footer -->
            <div class="login-footer">
                <p>Restricted Access • Authorized Personnel Only</p>
            </div>
        </div>
    </div>

    <script>
        // Toggle Password
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if(passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('bx-show');
                icon.classList.add('bx-hide');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('bx-hide');
                icon.classList.add('bx-show');
            }
        });

        // Auto focus
        document.getElementById('username').focus();
    </script>
</body>
</html>