<?php
ini_set("display_error", 0);
session_start();

if (!isset($_SESSION["user"]) && !isset($_SESSION["pass"])) {
    header("Location: index.php");
    exit();
}

$username = isset($_SESSION["user"]) ? $_SESSION["user"] : "Admin";

// Fungsi untuk menghitung jumlah line
function getLineCount($filename) {
    if (file_exists($filename)) {
        $lineCount = trim(shell_exec("wc -l < $filename"));
        return intval($lineCount);
    }
    return 0;
}

// Data file results
$file_results = [
    [
        'name' => 'CyberPanel',
        'filename' => 'bot/result/cyberpanel.txt',
        'icon' => 'bx bx-shield',
        'color' => '#3b82f6',
        'category' => 'Panel'
    ],
    [
        'name' => 'EVOPANEL',
        'filename' => 'bot/result/evopanel.txt',
        'icon' => 'bx bx-server',
        'color' => '#10b981',
        'category' => 'Panel'
    ],
    [
        'name' => 'OJS',
        'filename' => 'bot/result/ojs.txt',
        'icon' => 'bx bx-book',
        'color' => '#8b5cf6',
        'category' => 'CMS'
    ],
    [
        'name' => 'Drupal',
        'filename' => 'bot/result/drupal.txt',
        'icon' => 'bx bx-cube',
        'color' => '#f59e0b',
        'category' => 'CMS'
    ],
    [
        'name' => 'Moodle',
        'filename' => 'bot/result/moodle.txt',
        'icon' => 'bx bx-graduation',
        'color' => '#ef4444',
        'category' => 'LMS'
    ],
    [
        'name' => 'WordPress',
        'filename' => 'bot/result/wp.txt',
        'icon' => 'bx bxl-wordpress',
        'color' => '#21759b',
        'category' => 'CMS'
    ],
    [
        'name' => 'Joomla',
        'filename' => 'bot/result/joomla.txt',
        'icon' => 'bx bxl-joomla',
        'color' => '#5091cd',
        'category' => 'CMS'
    ],
    [
        'name' => 'Cpanel',
        'filename' => 'bot/result/cpanel.txt',
        'icon' => 'bx bx-cog',
        'color' => '#ff6c2f',
        'category' => 'Panel'
    ],
    [
        'name' => 'WHM',
        'filename' => 'bot/result/whm.txt',
        'icon' => 'bx bx-chip',
        'color' => '#06b6d4',
        'category' => 'Panel'
    ],
    [
        'name' => 'FTP',
        'filename' => 'bot/result/ftp.txt',
        'icon' => 'bx bx-folder',
        'color' => '#8b5cf6',
        'category' => 'Protocol'
    ],
    [
        'name' => 'PrestaShop',
        'filename' => 'bot/result/prestashop.txt',
        'icon' => 'bx bx-store',
        'color' => '#df0067',
        'category' => 'E-commerce'
    ],
    [
        'name' => 'Konoha',
        'filename' => 'bot/result/konoha.txt',
        'icon' => 'bx bx-code',
        'color' => '#10b981',
        'category' => 'Manual'
    ]
];

// Hitung total line
$total_lines = 0;
foreach ($file_results as $file) {
    $total_lines += getLineCount($file['filename']);
}

// Hitung total file
$total_files = count($file_results);

// Proses clear file jika ada parameter
if (isset($_GET["clear"])) {
    $paths = $_GET["clear"];
    if (file_exists($paths)) {
        file_put_contents($paths, "");
    }
    header("Location: listfile.php");
    exit();
}

// Proses clear all jika ada parameter
if (isset($_GET["clearall"])) {
    foreach ($file_results as $file) {
        if (file_exists($file['filename'])) {
            file_put_contents($file['filename'], "");
        }
    }
    header("Location: listfile.php");
    exit();
}

// Proses download all jika ada parameter
if (isset($_GET["downloadall"])) {
    // Create zip file
    $zip = new ZipArchive();
    $zip_filename = 'results_' . date('Y-m-d_H-i-s') . '.zip';
    
    if ($zip->open($zip_filename, ZipArchive::CREATE) === TRUE) {
        foreach ($file_results as $file) {
            if (file_exists($file['filename']) && filesize($file['filename']) > 0) {
                $zip->addFile($file['filename'], basename($file['filename']));
            }
        }
        $zip->close();
        
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zip_filename . '"');
        header('Content-Length: ' . filesize($zip_filename));
        readfile($zip_filename);
        unlink($zip_filename);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NULL7 AUTOMATIC LIST TOOLS | File Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel='stylesheet'>
    <link rel="stylesheet" href="assets/dashboard-premium.css">
    <style>
        /* Additional styles for file results page */
        .file-card {
            background: var(--card-bg);
            border-radius: 18px;
            padding: 25px;
            border: 1px solid var(--glass-border);
            transition: all 0.3s ease;
            height: 100%;
        }
        
        .file-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            border-color: var(--accent-blue);
        }
        
        .file-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
        }
        
        .file-icon-container {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: white;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }
        
        .file-category {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-secondary);
        }
        
        .file-title {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 5px;
        }
        
        .file-path {
            font-size: 12px;
            color: var(--text-muted);
            font-family: 'Monaco', 'Courier New', monospace;
            margin-bottom: 20px;
            word-break: break-all;
        }
        
        .file-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 12px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .file-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn-file {
            flex: 1;
            padding: 10px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .btn-download {
            background: rgba(37, 99, 235, 0.1);
            color: var(--accent-blue);
            border: 1px solid rgba(37, 99, 235, 0.2);
        }
        
        .btn-download:hover {
            background: rgba(37, 99, 235, 0.2);
            transform: translateY(-2px);
        }
        
        .btn-clear {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
        
        .btn-clear:hover {
            background: rgba(239, 68, 68, 0.2);
            transform: translateY(-2px);
        }
        
        .btn-view {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
            border: 1px solid rgba(16, 185, 129, 0.2);
        }
        
        .btn-view:hover {
            background: rgba(16, 185, 129, 0.2);
            transform: translateY(-2px);
        }
        
        /* Stats Overview */
        .stats-overview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .overview-card {
            background: var(--card-bg);
            border-radius: 18px;
            padding: 25px;
            border: 1px solid var(--glass-border);
            text-align: center;
        }
        
        .overview-icon {
            width: 60px;
            height: 60px;
            background: var(--accent-gradient);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 28px;
            color: white;
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.3);
        }
        
        .overview-value {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 5px;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-cyan));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .overview-label {
            color: var(--text-muted);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        /* Category Filter */
        .category-filter {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        
        .filter-btn {
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            border-radius: 10px;
            color: var(--text-secondary);
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .filter-btn:hover,
        .filter-btn.active {
            background: var(--accent-gradient);
            color: white;
            border-color: transparent;
        }
        
        /* Bulk Actions */
        .bulk-actions {
            background: var(--card-bg);
            border-radius: 18px;
            padding: 25px;
            border: 1px solid var(--glass-border);
            margin-bottom: 30px;
        }
        
        .bulk-title {
            color: var(--text-primary);
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .bulk-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .btn-bulk {
            padding: 14px 28px;
            border-radius: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s ease;
            border: none;
        }
        
        .btn-bulk-download {
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            color: white;
        }
        
        .btn-bulk-download:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(37, 99, 235, 0.3);
        }
        
        .btn-bulk-clear {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
        }
        
        .btn-bulk-clear:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(239, 68, 68, 0.3);
        }
        
        .btn-bulk-refresh {
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        
        .btn-bulk-refresh:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
        }
        
        /* Empty State */
        .empty-state-results {
            text-align: center;
            padding: 60px 20px;
            background: var(--card-bg);
            border-radius: 18px;
            border: 1px solid var(--glass-border);
        }
        
        .empty-icon-results {
            width: 80px;
            height: 80px;
            background: rgba(37, 99, 235, 0.1);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: var(--accent-blue);
            font-size: 36px;
        }
        
        /* File Size Badge */
        .file-size-badge {
            display: inline-block;
            padding: 4px 10px;
            background: rgba(255, 255, 255, 0.1);
            color: var(--text-secondary);
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            margin-left: 10px;
        }
        
        @media (max-width: 768px) {
            .file-stats {
                grid-template-columns: 1fr;
            }
            
            .file-actions {
                flex-direction: column;
            }
            
            .bulk-buttons {
                flex-direction: column;
            }
            
            .btn-bulk {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="mobile-menu-toggle" id="mobileMenuToggle">
        <i class='bx bx-menu'></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar-premium" id="sidebar">
        <div class="brand-section">
            <div class="brand-logo">
                <div class="logo-icon">
                    <i class='bx bx-code-alt'></i>
                </div>
                <div class="brand-text">
                    <h2>NULL7</h2>
                    <p>AUTOMATIC LIST TOOLS</p>
                </div>
            </div>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav-menu-premium">
            <li class="nav-item-premium">
                <a href="dashboard.php" class="nav-link-premium">
                    <i class='bx bx-home nav-icon'></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="listchannel.php" class="nav-link-premium">
                    <i class='bx bx-list-ul nav-icon'></i>
                    <span class="nav-text">List Channels</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="listfile.php" class="nav-link-premium active">
                    <i class='bx bx-folder nav-icon'></i>
                    <span class="nav-text">Results</span>
                    <span class="nav-badge"><?php echo $total_files; ?></span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="#" class="nav-link-premium">
                    <i class='bx bx-bar-chart nav-icon'></i>
                    <span class="nav-text">Analytics</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="logout.php" class="nav-link-premium">
                    <i class='bx bx-log-out nav-icon'></i>
                    <span class="nav-text">Logout</span>
                </a>
            </li>
        </ul>

        <!-- User Profile -->
        <div class="user-profile-premium">
            <div class="d-flex align-items-center">
                <div class="user-avatar-large">
                    <?php echo strtoupper(substr($username, 0, 1)); ?>
                </div>
                <div class="user-info-premium">
                    <h4><?php echo htmlspecialchars($username); ?></h4>
                    <p>Results Manager</p>
                    <div class="user-status">
                        <span class="status-indicator"></span>
                        <span class="text-success fw-bold">Online</span>
                    </div>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content-premium" id="mainContent">
        <!-- Header -->
        <header class="header-premium fade-in-up">
            <div class="welcome-section-premium">
                <h1>File Results Management</h1>
                <p>Manage and monitor your scanning results</p>
            </div>
            <div class="header-actions">
                <div class="search-container-premium">
                    <i class='bx bx-search search-icon-premium'></i>
                    <input type="text" class="search-input-premium" placeholder="Search results..." id="searchInput">
                </div>
                <button class="action-btn-icon" title="Export All" id="exportAllBtn">
                    <i class='bx bx-export'></i>
                </button>
                <button class="action-btn-icon" title="Refresh" id="refreshBtn">
                    <i class='bx bx-refresh'></i>
                </button>
            </div>
        </header>

        <!-- Stats Overview -->
        <div class="stats-overview fade-in-up">
            <div class="overview-card">
                <div class="overview-icon">
                    <i class='bx bx-folder'></i>
                </div>
                <div class="overview-value"><?php echo $total_files; ?></div>
                <div class="overview-label">Total Files</div>
            </div>
            
            <div class="overview-card">
                <div class="overview-icon">
                    <i class='bx bx-line-chart'></i>
                </div>
                <div class="overview-value"><?php echo number_format($total_lines); ?></div>
                <div class="overview-label">Total Lines</div>
            </div>
            
            <div class="overview-card">
                <div class="overview-icon">
                    <i class='bx bx-data'></i>
                </div>
                <div class="overview-value">
                    <?php 
                        $total_size = 0;
                        foreach ($file_results as $file) {
                            if (file_exists($file['filename'])) {
                                $total_size += filesize($file['filename']);
                            }
                        }
                        echo round($total_size / 1024 / 1024, 2);
                    ?> MB
                </div>
                <div class="overview-label">Total Size</div>
            </div>
            
            <div class="overview-card">
                <div class="overview-icon">
                    <i class='bx bx-check-circle'></i>
                </div>
                <div class="overview-value">
                    <?php 
                        $active_files = 0;
                        foreach ($file_results as $file) {
                            if (file_exists($file['filename']) && filesize($file['filename']) > 0) {
                                $active_files++;
                            }
                        }
                        echo $active_files;
                    ?>
                </div>
                <div class="overview-label">Active Files</div>
            </div>
        </div>

        <!-- Bulk Actions -->
        <div class="bulk-actions fade-in-up" style="animation-delay: 0.1s">
            <div class="bulk-title">
                <i class='bx bx-bulk'></i>
                <span>Bulk Operations</span>
            </div>
            <div class="bulk-buttons">
                <a href="?downloadall=true" class="btn-bulk btn-bulk-download" id="downloadAllBtn">
                    <i class='bx bx-download'></i>
                    Download All Results (ZIP)
                </a>
                <a href="?clearall=true" class="btn-bulk btn-bulk-clear" id="clearAllBtn" 
                   onclick="return confirm('Are you sure you want to clear ALL results? This action cannot be undone!')">
                    <i class='bx bx-trash'></i>
                    Clear All Results
                </a>
                <button class="btn-bulk btn-bulk-refresh" id="refreshAllBtn">
                    <i class='bx bx-refresh'></i>
                    Refresh All Data
                </button>
            </div>
        </div>

        <!-- Category Filter -->
        <div class="category-filter fade-in-up" style="animation-delay: 0.2s">
            <button class="filter-btn active" data-category="all">All Results</button>
            <?php 
                $categories = array_unique(array_column($file_results, 'category'));
                foreach ($categories as $category): 
            ?>
                <button class="filter-btn" data-category="<?php echo strtolower($category); ?>">
                    <?php echo htmlspecialchars($category); ?>
                </button>
            <?php endforeach; ?>
        </div>

        <!-- Results Grid -->
        <div class="row g-4" id="resultsGrid">
            <?php foreach ($file_results as $index => $file): 
                $line_count = getLineCount($file['filename']);
                $file_exists = file_exists($file['filename']);
                $file_size = $file_exists ? filesize($file['filename']) : 0;
            ?>
            <div class="col-xl-3 col-lg-4 col-md-6 file-card-container fade-in-up" 
                 data-category="<?php echo strtolower($file['category']); ?>"
                 style="animation-delay: <?php echo ($index * 0.05) + 0.3; ?>s">
                <div class="file-card">
                    <div class="file-header">
                        <div class="file-icon-container" style="background: <?php echo $file['color']; ?>;">
                            <i class='<?php echo $file['icon']; ?>'></i>
                        </div>
                        <span class="file-category"><?php echo $file['category']; ?></span>
                    </div>
                    
                    <div class="file-title">
                        <?php echo htmlspecialchars($file['name']); ?>
                        <?php if ($file_exists): ?>
                        <span class="file-size-badge">
                            <?php echo round($file_size / 1024, 2); ?> KB
                        </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="file-path" title="<?php echo htmlspecialchars($file['filename']); ?>">
                        <?php echo htmlspecialchars($file['filename']); ?>
                    </div>
                    
                    <div class="file-stats">
                        <div class="stat-item">
                            <div class="stat-value" style="color: <?php echo $file['color']; ?>;">
                                <?php echo number_format($line_count); ?>
                            </div>
                            <div class="stat-label">Lines</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">
                                <?php echo $file_exists ? '✅' : '❌'; ?>
                            </div>
                            <div class="stat-label">Status</div>
                        </div>
                    </div>
                    
                    <div class="file-actions">
                        <?php if ($file_exists && $file_size > 0): ?>
                            <a href="<?php echo $file['filename']; ?>" 
                               class="btn-file btn-download" 
                               target="_blank"
                               title="Download file">
                                <i class='bx bx-download'></i>
                                <span>Download</span>
                            </a>
                            
                            <a href="?clear=<?php echo urlencode($file['filename']); ?>" 
                               class="btn-file btn-clear"
                               onclick="return confirm('Clear <?php echo $file['name']; ?> results?')"
                               title="Clear file contents">
                                <i class='bx bx-trash'></i>
                                <span>Clear</span>
                            </a>
                            
                            <button class="btn-file btn-view view-file-btn" 
                                    data-filename="<?php echo htmlspecialchars($file['filename']); ?>"
                                    data-title="<?php echo htmlspecialchars($file['name']); ?>"
                                    title="View file content">
                                <i class='bx bx-show'></i>
                                <span>View</span>
                            </button>
                        <?php else: ?>
                            <div class="btn-file btn-download disabled" style="opacity: 0.5;">
                                <i class='bx bx-x'></i>
                                <span>No Data</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <?php if ($total_lines === 0): ?>
        <div class="empty-state-results fade-in-up" style="animation-delay: 0.4s">
            <div class="empty-icon-results">
                <i class='bx bx-file'></i>
            </div>
            <div class="empty-title">No Results Found</div>
            <div class="empty-description">
                No scanning results available yet. Start scanning to generate results.
            </div>
        </div>
        <?php endif; ?>

        <!-- Footer -->
        <footer class="footer-premium mt-4">
            <div class="copyright">
                <div class="d-flex align-items-center justify-content-center mb-2">
                    <strong>NULL7 AUTOMATIC LIST TOOLS</strong>
                    <span class="version-badge">Results Manager</span>
                </div>
                <div class="text-muted">
                    <i class='bx bx-time'></i> Last updated: <span id="currentTime"><?php echo date("H:i"); ?></span> | 
                    <i class='bx bx-user'></i> User: <?php echo htmlspecialchars($username); ?> | 
                    <i class='bx bx-data'></i> Results: <?php echo $total_files; ?> files, <?php echo number_format($total_lines); ?> lines
                </div>
                <div class="mt-2">
                    <pre class="mb-0" style="color: var(--text-muted); font-size: 0.7rem;">© 2024 NULL7 Tools | X - MrG3P5 | 2K24</pre>
                </div>
            </div>
        </footer>
    </main>

    <!-- File Viewer Modal -->
    <div class="modal fade" id="fileViewerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content glass" style="background: var(--card-bg); border: 1px solid var(--glass-border);">
                <div class="modal-header" style="border-bottom: 1px solid var(--glass-border);">
                    <h5 class="modal-title text-white" id="fileViewerTitle"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-0">
                    <div class="d-flex" style="height: 500px;">
                        <div class="flex-shrink-0 border-end border-secondary" style="width: 200px; background: rgba(0,0,0,0.2);">
                            <div class="p-3">
                                <div class="mb-3">
                                    <small class="text-muted d-block mb-1">File Info</small>
                                    <div id="fileInfo" class="text-white small"></div>
                                </div>
                                <div class="mb-3">
                                    <small class="text-muted d-block mb-1">Actions</small>
                                    <button class="btn btn-sm btn-primary w-100 mb-2" id="copyFileContent">
                                        <i class='bx bx-copy'></i> Copy All
                                    </button>
                                    <button class="btn btn-sm btn-success w-100" id="downloadFromModal">
                                        <i class='bx bx-download'></i> Download
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="flex-grow-1 position-relative">
                            <pre id="fileContent" class="m-0 p-3 text-white" 
                                 style="height: 100%; overflow: auto; background: transparent; font-family: 'Monaco', 'Courier New', monospace; font-size: 12px; white-space: pre-wrap;"></pre>
                            <div id="fileLoading" class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" 
                                 style="background: rgba(0,0,0,0.7); display: none;">
                                <div class="text-center">
                                    <i class='bx bx-loader-circle bx-spin' style="font-size: 40px; color: var(--accent-blue);"></i>
                                    <div class="mt-2 text-white">Loading file content...</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mobile Menu Toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        
        mobileMenuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('mobile-open');
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth < 992 && 
                !sidebar.contains(e.target) && 
                !mobileMenuToggle.contains(e.target)) {
                sidebar.classList.remove('mobile-open');
            }
        });
        
        // Update current time
        function updateTime() {
            const currentTimeEl = document.getElementById('currentTime');
            if (currentTimeEl) {
                const now = new Date();
                currentTimeEl.textContent = now.toLocaleTimeString('en-US', { 
                    hour12: false,
                    hour: '2-digit',
                    minute: '2-digit'
                });
            }
        }
        
        setInterval(updateTime, 1000);
        
        // Search functionality
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const fileCards = document.querySelectorAll('.file-card-container');
            
            fileCards.forEach(card => {
                const title = card.querySelector('.file-title').textContent.toLowerCase();
                const category = card.querySelector('.file-category').textContent.toLowerCase();
                const filename = card.querySelector('.file-path').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || category.includes(searchTerm) || filename.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
        
        // Category filter
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remove active class from all buttons
                filterButtons.forEach(b => b.classList.remove('active'));
                
                // Add active class to clicked button
                this.classList.add('active');
                
                const category = this.dataset.category;
                const fileCards = document.querySelectorAll('.file-card-container');
                
                fileCards.forEach(card => {
                    if (category === 'all' || card.dataset.category === category) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
        
        // Export All button
        document.getElementById('exportAllBtn').addEventListener('click', function() {
            window.location.href = '?downloadall=true';
        });
        
        // Refresh button
        document.getElementById('refreshBtn').addEventListener('click', function() {
            this.classList.add('bx-spin');
            setTimeout(() => {
                location.reload();
            }, 500);
        });
        
        // Refresh All button
        document.getElementById('refreshAllBtn').addEventListener('click', function() {
            this.innerHTML = '<i class="bx bx-loader-circle bx-spin"></i> Refreshing...';
            this.disabled = true;
            
            setTimeout(() => {
                location.reload();
            }, 1000);
        });
        
        // Clear All confirmation
        document.getElementById('clearAllBtn').addEventListener('click', function(e) {
            if (!confirm('⚠️ WARNING: This will clear ALL result files!\n\nThis action cannot be undone. Are you sure?')) {
                e.preventDefault();
            } else {
                this.innerHTML = '<i class="bx bx-loader-circle bx-spin"></i> Clearing...';
            }
        });
        
        // File viewer modal
        const fileViewerModal = new bootstrap.Modal(document.getElementById('fileViewerModal'));
        const viewFileButtons = document.querySelectorAll('.view-file-btn');
        
        viewFileButtons.forEach(btn => {
            btn.addEventListener('click', async function() {
                const filename = this.dataset.filename;
                const title = this.dataset.title;
                
                // Set modal title
                document.getElementById('fileViewerTitle').textContent = `Viewing: ${title}`;
                
                // Show loading
                document.getElementById('fileLoading').style.display = 'flex';
                fileViewerModal.show();
                
                try {
                    // Fetch file content
                    const response = await fetch(filename);
                    if (response.ok) {
                        const content = await response.text();
                        
                        // Get file info
                        const fileInfo = await fetch(`${filename}?info=1`);
                        const fileStats = fileInfo.headers;
                        
                        // Set file info
                        const fileSize = (content.length / 1024).toFixed(2);
                        const lineCount = content.split('\n').length;
                        document.getElementById('fileInfo').innerHTML = `
                            <div>Size: ${fileSize} KB</div>
                            <div>Lines: ${lineCount}</div>
                            <div>Path: ${filename}</div>
                        `;
                        
                        // Set file content with syntax highlighting
                        document.getElementById('fileContent').textContent = content;
                        
                        // Set download button
                        document.getElementById('downloadFromModal').onclick = () => {
                            window.location.href = filename;
                        };
                    } else {
                        document.getElementById('fileContent').textContent = 'Error loading file content.';
                    }
                } catch (error) {
                    document.getElementById('fileContent').textContent = 'Error: ' + error.message;
                } finally {
                    // Hide loading
                    document.getElementById('fileLoading').style.display = 'none';
                }
            });
        });
        
        // Copy file content
        document.getElementById('copyFileContent').addEventListener('click', function() {
            const content = document.getElementById('fileContent').textContent;
            navigator.clipboard.writeText(content).then(() => {
                this.innerHTML = '<i class="bx bx-check"></i> Copied!';
                setTimeout(() => {
                    this.innerHTML = '<i class="bx bx-copy"></i> Copy All';
                }, 2000);
            });
        });
        
        // Toast notification function
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast-notification toast-${type}`;
            toast.innerHTML = `
                <div class="toast-icon">
                    <i class='bx bx-${type === 'success' ? 'check-circle' : type === 'warning' ? 'error-circle' : 'info-circle'}'></i>
                </div>
                <div class="toast-message">${message}</div>
                <button class="toast-close"><i class='bx bx-x'></i></button>
            `;
            
            // Add styles
            toast.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#10b981' : type === 'warning' ? '#f59e0b' : '#3b82f6'};
                color: white;
                padding: 15px 20px;
                border-radius: 10px;
                display: flex;
                align-items: center;
                gap: 12px;
                z-index: 9999;
                animation: slideIn 0.3s ease;
                max-width: 400px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            `;
            
            document.body.appendChild(toast);
            
            // Close button
            toast.querySelector('.toast-close').addEventListener('click', () => {
                toast.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => toast.remove(), 300);
            });
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.style.animation = 'slideOut 0.3s ease';
                    setTimeout(() => toast.remove(), 300);
                }
            }, 5000);
        }
        
        // Add animation styles for toast
        const toastStyle = document.createElement('style');
        toastStyle.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            
            .toast-notification .toast-icon {
                font-size: 20px;
            }
            
            .toast-notification .toast-message {
                flex: 1;
                font-size: 14px;
            }
            
            .toast-notification .toast-close {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                font-size: 18px;
                padding: 0;
            }
        `;
        document.head.appendChild(toastStyle);
        
        // Theme toggle
        const themeToggle = document.createElement('button');
        themeToggle.className = 'action-btn-icon';
        themeToggle.innerHTML = '<i class="bx bx-moon"></i>';
        themeToggle.title = 'Toggle Theme';
        
        themeToggle.addEventListener('click', function() {
            const icon = this.querySelector('i');
            if (icon.classList.contains('bx-moon')) {
                icon.classList.remove('bx-moon');
                icon.classList.add('bx-sun');
                document.body.classList.add('light-theme');
                showToast('Light theme activated', 'info');
            } else {
                icon.classList.remove('bx-sun');
                icon.classList.add('bx-moon');
                document.body.classList.remove('light-theme');
                showToast('Dark theme activated', 'info');
            }
        });
        
        // Add theme toggle to header
        document.querySelector('.header-actions').appendChild(themeToggle);
        
        // Light theme styles
        const lightThemeStyle = document.createElement('style');
        lightThemeStyle.textContent = `
            body.light-theme .file-card,
            body.light-theme .overview-card,
            body.light-theme .bulk-actions {
                background: rgba(255, 255, 255, 0.9);
                border-color: rgba(0, 0, 0, 0.1);
            }
            
            body.light-theme .file-title {
                color: #0f172a;
            }
            
            body.light-theme .file-path {
                color: #64748b;
            }
            
            body.light-theme .filter-btn {
                background: rgba(0, 0, 0, 0.05);
                border-color: rgba(0, 0, 0, 0.1);
                color: #475569;
            }
            
            body.light-theme .btn-file {
                background: rgba(0, 0, 0, 0.05);
            }
            
            body.light-theme #fileViewerModal .modal-content {
                background: rgba(255, 255, 255, 0.95) !important;
            }
            
            body.light-theme #fileContent {
                color: #0f172a !important;
            }
        `;
        document.head.appendChild(lightThemeStyle);
        
        // Initialize with animations
        document.addEventListener('DOMContentLoaded', function() {
            // Animate elements on load
            const animatedElements = document.querySelectorAll('.fade-in-up');
            animatedElements.forEach((el, index) => {
                setTimeout(() => {
                    el.style.opacity = '1';
                    el.style.transform = 'translateY(0)';
                }, index * 100);
            });
            
            // Set initial styles for animation
            animatedElements.forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            });
            
            // Show welcome message
            setTimeout(() => {
                if (<?php echo $total_lines; ?> > 0) {
                    showToast(`Loaded ${<?php echo $total_files; ?>} files with ${<?php echo number_format($total_lines); ?>} total lines`, 'success');
                }
            }, 1000);
            
            // Add click animation to file cards
            document.querySelectorAll('.file-card').forEach(card => {
                card.addEventListener('click', function(e) {
                    if (!e.target.closest('.btn-file') && !e.target.closest('.view-file-btn')) {
                        this.style.transform = 'translateY(-5px) scale(1.02)';
                        setTimeout(() => {
                            this.style.transform = 'translateY(-5px)';
                        }, 150);
                    }
                });
            });
            
            // Auto-refresh data every 30 seconds
            setInterval(() => {
                const refreshBtn = document.getElementById('refreshAllBtn');
                if (refreshBtn && !refreshBtn.disabled) {
                    refreshBtn.click();
                }
            }, 30000);
        });
        
        // File preview on hover (small preview)
        const fileCards = document.querySelectorAll('.file-card');
        fileCards.forEach(card => {
            const viewBtn = card.querySelector('.view-file-btn');
            if (viewBtn) {
                card.addEventListener('mouseenter', function() {
                    const filename = viewBtn.dataset.filename;
                    // Could add a small preview tooltip here if needed
                });
            }
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Ctrl + F for search
            if (e.ctrlKey && e.key === 'f') {
                e.preventDefault();
                searchInput.focus();
            }
            
            // Escape to clear search
            if (e.key === 'Escape') {
                searchInput.value = '';
                searchInput.dispatchEvent(new Event('keyup'));
                searchInput.blur();
            }
            
            // Ctrl + R to refresh
            if (e.ctrlKey && e.key === 'r') {
                e.preventDefault();
                document.getElementById('refreshAllBtn').click();
            }
        });
    </script>
</body>
</html>