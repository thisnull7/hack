<?php
session_start();

// Cek login
if (!isset($_SESSION['user']) && !isset($_SESSION['pass'])) {
    header("Location: index.php");
    exit();
}

$username = isset($_SESSION['user']) ? $_SESSION['user'] : "Admin";

// Data untuk dashboard
$system_data = [
    'total_channels' => 24,
    'total_results' => 156,
    'active_users' => 8,
    'processing_tasks' => 3,
    'success_rate' => 98.5,
    'system_status' => 'Optimal',
    'uptime_percentage' => 99.8,
    'storage_usage' => 65,
    'memory_usage' => round(memory_get_usage() / 1024 / 1024, 2),
    'cpu_usage' => 42,
    'bandwidth_usage' => 1.2,
    'response_time' => '45ms'
];

// Tools list
$tools_list = [
    [
        'icon' => 'bx bx-list-check',
        'title' => 'Auto List Builder',
        'desc' => 'Automatically generate and manage lists',
        'status' => 'active',
        'color' => '#3b82f6'
    ],
    [
        'icon' => 'bx bx-data',
        'title' => 'Data Processor',
        'desc' => 'Process and analyze large datasets',
        'status' => 'active',
        'color' => '#10b981'
    ],
    [
        'icon' => 'bx bx-filter-alt',
        'title' => 'Smart Filter',
        'desc' => 'Intelligent data filtering system',
        'status' => 'active',
        'color' => '#8b5cf6'
    ],
    [
        'icon' => 'bx bx-sort',
        'title' => 'Auto Sorter',
        'desc' => 'Automatic data sorting algorithms',
        'status' => 'active',
        'color' => '#f59e0b'
    ],
    [
        'icon' => 'bx bx-duplicate',
        'title' => 'Duplicate Remover',
        'desc' => 'Remove duplicates from lists',
        'status' => 'active',
        'color' => '#ef4444'
    ],
    [
        'icon' => 'bx bx-merge',
        'title' => 'List Merger',
        'desc' => 'Merge multiple lists intelligently',
        'status' => 'active',
        'color' => '#06b6d4'
    ],
    [
        'icon' => 'bx bx-export',
        'title' => 'Export Manager',
        'desc' => 'Export lists in multiple formats',
        'status' => 'active',
        'color' => '#8b5cf6'
    ],
    [
        'icon' => 'bx bx-cloud-upload',
        'title' => 'Cloud Sync',
        'desc' => 'Sync lists across cloud services',
        'status' => 'active',
        'color' => '#3b82f6'
    ]
];

// Recent activities
$recent_activities = [
    ['icon' => 'bx bx-list-check', 'title' => 'Auto List Builder completed processing 5000 entries', 'time' => '10 minutes ago', 'status' => 'success'],
    ['icon' => 'bx bx-data', 'title' => 'Data Processor optimized 2.3GB dataset', 'time' => '1 hour ago', 'status' => 'success'],
    ['icon' => 'bx bx-filter-alt', 'title' => 'Smart Filter detected 150 invalid entries', 'time' => '3 hours ago', 'status' => 'warning'],
    ['icon' => 'bx bx-sort', 'title' => 'Auto Sorter processed user request', 'time' => '5 hours ago', 'status' => 'processing'],
    ['icon' => 'bx bx-duplicate', 'title' => 'Duplicate Remover cleaned 1200 entries', 'time' => 'Yesterday', 'status' => 'success'],
    ['icon' => 'bx bx-merge', 'title' => 'List Merger combined 3 datasets', 'time' => '2 days ago', 'status' => 'success']
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NULL7 AUTOMATIC LIST TOOLS | Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel='stylesheet'>
    <link rel="stylesheet" href="assets/dashboard-premium.css">
    <link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>⚡</text></svg>">
    <style>
        /* Additional custom styles */
        .tool-card[data-status="active"] .tool-icon {
            box-shadow: 0 10px 25px rgba(59, 130, 246, 0.3);
        }
        
        .tool-card[data-status="inactive"] .tool-icon {
            background: #64748b;
            opacity: 0.7;
        }
        
        .stat-card-premium:nth-child(1) .stat-icon-container { background: linear-gradient(135deg, #3b82f6, #1d4ed8); }
        .stat-card-premium:nth-child(2) .stat-icon-container { background: linear-gradient(135deg, #10b981, #059669); }
        .stat-card-premium:nth-child(3) .stat-icon-container { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
        .stat-card-premium:nth-child(4) .stat-icon-container { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .stat-card-premium:nth-child(5) .stat-icon-container { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .stat-card-premium:nth-child(6) .stat-icon-container { background: linear-gradient(135deg, #06b6d4, #0891b2); }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="mobile-menu-toggle" id="mobileMenuToggle">
        <i class='bx bx-menu'></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar-premium" id="sidebar">
        <div class="brand-section">
            <div class="brand-logo">
                <div class="logo-icon">
                    <i class='bx bx-code-alt'></i>
                </div>
                <div class="brand-text">
                    <h2>NULL7</h2>
                    <p>AUTOMATIC LIST TOOLS</p>
                </div>
            </div>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav-menu-premium">
            <li class="nav-item-premium">
                <a href="dashboard.php" class="nav-link-premium active">
                    <i class='bx bx-home nav-icon'></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="listchannel.php" class="nav-link-premium">
                    <i class='bx bx-list-ul nav-icon'></i>
                    <span class="nav-text">List Channels</span>
                    <span class="nav-badge"><?php echo $system_data['total_channels']; ?></span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="listfile.php" class="nav-link-premium">
                    <i class='bx bx-folder nav-icon'></i>
                    <span class="nav-text">Results</span>
                    <span class="nav-badge"><?php echo $system_data['total_results']; ?></span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="#" class="nav-link-premium">
                    <i class='bx bx-bar-chart nav-icon'></i>
                    <span class="nav-text">Analytics</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="#" class="nav-link-premium">
                    <i class='bx bx-cog nav-icon'></i>
                    <span class="nav-text">Settings</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="#" class="nav-link-premium">
                    <i class='bx bx-bell nav-icon'></i>
                    <span class="nav-text">Notifications</span>
                    <span class="nav-badge">3</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="logout.php" class="nav-link-premium">
                    <i class='bx bx-log-out nav-icon'></i>
                    <span class="nav-text">Logout</span>
                </a>
            </li>
        </ul>

        <!-- User Profile -->
        <div class="user-profile-premium">
            <div class="d-flex align-items-center">
                <div class="user-avatar-large">
                    <?php echo strtoupper(substr($username, 0, 1)); ?>
                </div>
                <div class="user-info-premium">
                    <h4><?php echo htmlspecialchars($username); ?></h4>
                    <p>System Administrator</p>
                    <div class="user-status">
                        <span class="status-indicator"></span>
                        <span class="text-success fw-bold">Online</span>
                    </div>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content-premium" id="mainContent">
        <!-- Header -->
        <header class="header-premium fade-in-up">
            <div class="welcome-section-premium">
                <h1>Welcome to NULL7 Tools, <?php echo htmlspecialchars($username); ?>!</h1>
                <p>Automatic list processing system is running optimally</p>
            </div>
            <div class="header-actions">
                <div class="search-container-premium">
                    <i class='bx bx-search search-icon-premium'></i>
                    <input type="text" class="search-input-premium" placeholder="Search tools, lists, or results...">
                </div>
                <button class="action-btn-icon" title="Notifications">
                    <i class='bx bx-bell'></i>
                    <span class="notification-badge">3</span>
                </button>
                <button class="action-btn-icon" title="Settings" id="settingsBtn">
                    <i class='bx bx-cog'></i>
                </button>
            </div>
        </header>

        <!-- System Stats -->
        <div class="stats-grid-premium">
            <!-- Total Channels -->
            <div class="stat-card-premium fade-in-up" style="animation-delay: 0.1s">
                <div class="stat-header-premium">
                    <div class="stat-icon-container">
                        <i class='bx bx-list-ul'></i>
                    </div>
                    <div class="stat-trend trend-up">
                        <i class='bx bx-up-arrow-alt'></i>
                        +2
                    </div>
                </div>
                <div class="stat-value-premium"><?php echo $system_data['total_channels']; ?></div>
                <div class="stat-label-premium">Active Channels</div>
                <div class="stat-progress-premium">
                    <div class="progress-bar-premium" style="width: 85%; background: #3b82f6;"></div>
                </div>
            </div>

            <!-- Total Results -->
            <div class="stat-card-premium fade-in-up" style="animation-delay: 0.2s">
                <div class="stat-header-premium">
                    <div class="stat-icon-container">
                        <i class='bx bx-folder'></i>
                    </div>
                    <div class="stat-trend trend-up">
                        <i class='bx bx-up-arrow-alt'></i>
                        +12
                    </div>
                </div>
                <div class="stat-value-premium"><?php echo $system_data['total_results']; ?></div>
                <div class="stat-label-premium">Processed Results</div>
                <div class="stat-progress-premium">
                    <div class="progress-bar-premium" style="width: 92%; background: #10b981;"></div>
                </div>
            </div>

            <!-- Active Users -->
            <div class="stat-card-premium fade-in-up" style="animation-delay: 0.3s">
                <div class="stat-header-premium">
                    <div class="stat-icon-container">
                        <i class='bx bx-user'></i>
                    </div>
                    <div class="stat-trend trend-up">
                        <i class='bx bx-up-arrow-alt'></i>
                        +1
                    </div>
                </div>
                <div class="stat-value-premium"><?php echo $system_data['active_users']; ?></div>
                <div class="stat-label-premium">Active Users</div>
                <div class="stat-progress-premium">
                    <div class="progress-bar-premium" style="width: 75%; background: #8b5cf6;"></div>
                </div>
            </div>

            <!-- Processing Tasks -->
            <div class="stat-card-premium fade-in-up" style="animation-delay: 0.4s">
                <div class="stat-header-premium">
                    <div class="stat-icon-container">
                        <i class='bx bx-task'></i>
                    </div>
                    <div class="stat-trend trend-down">
                        <i class='bx bx-down-arrow-alt'></i>
                        -1
                    </div>
                </div>
                <div class="stat-value-premium"><?php echo $system_data['processing_tasks']; ?></div>
                <div class="stat-label-premium">Processing Tasks</div>
                <div class="stat-progress-premium">
                    <div class="progress-bar-premium" style="width: 40%; background: #f59e0b;"></div>
                </div>
            </div>

            <!-- Success Rate -->
            <div class="stat-card-premium fade-in-up" style="animation-delay: 0.5s">
                <div class="stat-header-premium">
                    <div class="stat-icon-container">
                        <i class='bx bx-check-circle'></i>
                    </div>
                    <div class="stat-trend trend-up">
                        <i class='bx bx-up-arrow-alt'></i>
                        +0.5%
                    </div>
                </div>
                <div class="stat-value-premium"><?php echo $system_data['success_rate']; ?>%</div>
                <div class="stat-label-premium">Success Rate</div>
                <div class="stat-progress-premium">
                    <div class="progress-bar-premium" style="width: <?php echo $system_data['success_rate']; ?>%; background: #ef4444;"></div>
                </div>
            </div>

            <!-- System Uptime -->
            <div class="stat-card-premium fade-in-up" style="animation-delay: 0.6s">
                <div class="stat-header-premium">
                    <div class="stat-icon-container">
                        <i class='bx bx-server'></i>
                    </div>
                    <div class="stat-trend trend-up">
                        <i class='bx bx-up-arrow-alt'></i>
                        +0.2%
                    </div>
                </div>
                <div class="stat-value-premium"><?php echo $system_data['uptime_percentage']; ?>%</div>
                <div class="stat-label-premium">System Uptime</div>
                <div class="stat-progress-premium">
                    <div class="progress-bar-premium" style="width: <?php echo $system_data['uptime_percentage']; ?>%; background: #06b6d4;"></div>
                </div>
            </div>
        </div>

        <!-- Tools Section -->
        <div class="dashboard-grid">
            <div>
                <h3 class="text-white mb-4">⚡ Automatic List Tools</h3>
                <div class="tools-grid">
                    <?php foreach($tools_list as $index => $tool): ?>
                    <a href="#" class="tool-card fade-in-up" data-status="<?php echo $tool['status']; ?>"
                       style="animation-delay: <?php echo ($index * 0.1) + 0.7; ?>s">
                        <div class="tool-icon" style="background: <?php echo $tool['color']; ?>;">
                            <i class='<?php echo $tool['icon']; ?>'></i>
                        </div>
                        <div class="tool-title"><?php echo $tool['title']; ?></div>
                        <div class="tool-desc"><?php echo $tool['desc']; ?></div>
                        <span class="tool-badge">Active</span>
                    </a>
                    <?php endforeach; ?>
                </div>

                <!-- System Information -->
                <div class="activity-card-premium mt-4">
                    <h5 class="text-white mb-4">🖥️ System Information</h5>
                    <div class="system-info-grid">
                        <div class="info-card-premium">
                            <div class="info-label-premium">Server Time</div>
                            <div class="info-value-premium" id="serverTime"><?php echo date("Y-m-d H:i:s"); ?></div>
                        </div>
                        <div class="info-card-premium">
                            <div class="info-label-premium">PHP Version</div>
                            <div class="info-value-premium"><?php echo phpversion(); ?></div>
                        </div>
                        <div class="info-card-premium">
                            <div class="info-label-premium">Memory Usage</div>
                            <div class="info-value-premium"><?php echo $system_data['memory_usage']; ?> MB</div>
                        </div>
                        <div class="info-card-premium">
                            <div class="info-label-premium">CPU Usage</div>
                            <div class="info-value-premium"><?php echo $system_data['cpu_usage']; ?>%</div>
                        </div>
                        <div class="info-card-premium">
                            <div class="info-label-premium">Storage Usage</div>
                            <div class="info-value-premium"><?php echo $system_data['storage_usage']; ?>%</div>
                        </div>
                        <div class="info-card-premium">
                            <div class="info-label-premium">Response Time</div>
                            <div class="info-value-premium"><?php echo $system_data['response_time']; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div>
                <div class="activity-card-premium">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="text-white mb-0">📋 Recent Activity</h5>
                        <a href="#" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="activity-list">
                        <?php foreach($recent_activities as $activity): ?>
                        <div class="activity-item-premium">
                            <div class="activity-icon-premium">
                                <i class='<?php echo $activity['icon']; ?>'></i>
                            </div>
                            <div class="activity-content-premium">
                                <div class="activity-title-premium"><?php echo $activity['title']; ?></div>
                                <div class="activity-time-premium"><?php echo $activity['time']; ?></div>
                            </div>
                            <div class="activity-status-premium status-<?php echo $activity['status']; ?>">
                                <?php echo ucfirst($activity['status']); ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="activity-card-premium mt-4">
                    <h5 class="text-white mb-4">🚀 Quick Actions</h5>
                    <div class="row g-3">
                        <div class="col-6">
                            <a href="listchannel.php" class="btn btn-primary w-100 d-flex align-items-center justify-content-center py-3">
                                <i class='bx bx-plus-circle me-2'></i> Add Channel
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="listfile.php" class="btn btn-success w-100 d-flex align-items-center justify-content-center py-3">
                                <i class='bx bx-upload me-2'></i> Upload Results
                            </a>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-info w-100 d-flex align-items-center justify-content-center py-3" id="exportBtn">
                                <i class='bx bx-download me-2'></i> Export Data
                            </button>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-warning w-100 d-flex align-items-center justify-content-center py-3" id="processBtn">
                                <i class='bx bx-play-circle me-2'></i> Process All
                            </button>
                        </div>
                    </div>
                </div>

                <!-- System Status -->
                <div class="activity-card-premium mt-4">
                    <h5 class="text-white mb-3">🔧 System Status</h5>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span>All Services</span>
                        <span class="badge bg-success">Operational</span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span>API Response</span>
                        <span class="badge bg-success"><?php echo $system_data['response_time']; ?></span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <span>Last Backup</span>
                        <span class="text-muted">2 hours ago</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer-premium">
            <div class="copyright">
                <div class="d-flex align-items-center justify-content-center mb-2">
                    <strong>NULL7 AUTOMATIC LIST TOOLS</strong>
                    <span class="version-badge">v3.0</span>
                </div>
                <div class="text-muted">
                    <i class='bx bx-time'></i> Last updated: <span id="currentTime"><?php echo date("H:i"); ?></span> | 
                    <i class='bx bx-user'></i> User: <?php echo htmlspecialchars($username); ?> | 
                    <i class='bx bx-server'></i> Status: <span class="text-success">Optimal</span>
                </div>
                <div class="mt-2">
                    <pre class="mb-0" style="color: var(--text-muted); font-size: 0.7rem;">© 2024 NULL7 Tools | X - MrG3P5 | 2K24</pre>
                </div>
            </div>
        </footer>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mobile Menu Toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        
        mobileMenuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('mobile-open');
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth < 992 && 
                !sidebar.contains(e.target) && 
                !mobileMenuToggle.contains(e.target)) {
                sidebar.classList.remove('mobile-open');
            }
        });
        
        // Update time function
        function updateTime() {
            const now = new Date();
            const serverTimeEl = document.getElementById('serverTime');
            const currentTimeEl = document.getElementById('currentTime');
            
            if (serverTimeEl) {
                serverTimeEl.textContent = now.toISOString().replace('T', ' ').substr(0, 19);
            }
            
            if (currentTimeEl) {
                currentTimeEl.textContent = now.toLocaleTimeString('en-US', { 
                    hour12: false,
                    hour: '2-digit',
                    minute: '2-digit'
                });
            }
        }
        
        // Update time every second
        setInterval(updateTime, 1000);
        
        // Tool cards animation on hover
        document.querySelectorAll('.tool-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-5px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
        
        // Search functionality
        const searchInput = document.querySelector('.search-input-premium');
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                const query = this.value.trim();
                if (query) {
                    // Simulate search
                    const toolCards = document.querySelectorAll('.tool-card');
                    toolCards.forEach(card => {
                        const title = card.querySelector('.tool-title').textContent.toLowerCase();
                        const desc = card.querySelector('.tool-desc').textContent.toLowerCase();
                        
                        if (title.includes(query.toLowerCase()) || desc.includes(query.toLowerCase())) {
                            card.style.display = 'block';
                            card.classList.add('pulse');
                            setTimeout(() => card.classList.remove('pulse'), 1000);
                        } else {
                            card.style.display = 'none';
                        }
                    });
                    
                    // Show message if no results
                    const visibleCards = document.querySelectorAll('.tool-card[style*="block"]');
                    if (visibleCards.length === 0) {
                        alert('No tools found for: ' + query);
                    }
                }
            }
        });
        
        // Clear search on escape
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                this.value = '';
                document.querySelectorAll('.tool-card').forEach(card => {
                    card.style.display = 'block';
                });
            }
        });
        
        // Button actions
        document.getElementById('exportBtn').addEventListener('click', function() {
            this.innerHTML = '<i class="bx bx-loader-circle bx-spin me-2"></i> Exporting...';
            this.disabled = true;
            
            setTimeout(() => {
                this.innerHTML = '<i class="bx bx-download me-2"></i> Export Data';
                this.disabled = false;
                showToast('Data exported successfully!', 'success');
            }, 2000);
        });
        
        document.getElementById('processBtn').addEventListener('click', function() {
            this.innerHTML = '<i class="bx bx-loader-circle bx-spin me-2"></i> Processing...';
            this.disabled = true;
            
            setTimeout(() => {
                this.innerHTML = '<i class="bx bx-play-circle me-2"></i> Process All';
                this.disabled = false;
                showToast('All tasks processed successfully!', 'success');
            }, 3000);
        });
        
        document.getElementById('settingsBtn').addEventListener('click', function() {
            showToast('Settings panel opened', 'info');
        });
        
        // Notification bell
        document.querySelector('.action-btn-icon').addEventListener('click', function() {
            showToast('You have 3 unread notifications', 'info');
        });
        
        // Toast notification function
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast-notification toast-${type}`;
            toast.innerHTML = `
                <div class="toast-icon">
                    <i class='bx bx-${type === 'success' ? 'check-circle' : type === 'warning' ? 'error-circle' : 'info-circle'}'></i>
                </div>
                <div class="toast-message">${message}</div>
                <button class="toast-close"><i class='bx bx-x'></i></button>
            `;
            
            // Add styles
            toast.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#10b981' : type === 'warning' ? '#f59e0b' : '#3b82f6'};
                color: white;
                padding: 15px 20px;
                border-radius: 10px;
                display: flex;
                align-items: center;
                gap: 12px;
                z-index: 9999;
                animation: slideIn 0.3s ease;
                max-width: 400px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            `;
            
            document.body.appendChild(toast);
            
            // Close button
            toast.querySelector('.toast-close').addEventListener('click', () => {
                toast.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => toast.remove(), 300);
            });
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.style.animation = 'slideOut 0.3s ease';
                    setTimeout(() => toast.remove(), 300);
                }
            }, 5000);
        }
        
        // Add animation styles
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            
            .toast-notification .toast-icon {
                font-size: 20px;
            }
            
            .toast-notification .toast-message {
                flex: 1;
                font-size: 14px;
            }
            
            .toast-notification .toast-close {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                font-size: 18px;
                padding: 0;
            }
        `;
        document.head.appendChild(style);
        
        // Initialize tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[title]'));
        const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Add ripple effect to buttons
        document.querySelectorAll('.btn, .action-btn-icon').forEach(button => {
            button.addEventListener('click', function(e) {
                const rect = this.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                const ripple = document.createElement('span');
                ripple.style.cssText = `
                    position: absolute;
                    border-radius: 50%;
                    background: rgba(255,255,255,0.5);
                    transform: scale(0);
                    animation: ripple 0.6s linear;
                    pointer-events: none;
                    left: ${x}px;
                    top: ${y}px;
                    width: 100px;
                    height: 100px;
                    margin-left: -50px;
                    margin-top: -50px;
                `;
                
                this.style.position = 'relative';
                this.style.overflow = 'hidden';
                this.appendChild(ripple);
                
                setTimeout(() => ripple.remove(), 600);
            });
        });
        
        // Add ripple animation
        const rippleStyle = document.createElement('style');
        rippleStyle.textContent = `
            @keyframes ripple {
                to {
                    transform: scale(4);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(rippleStyle);
        
        // Theme toggle (simplified)
        const themeToggle = document.createElement('button');
        themeToggle.className = 'action-btn-icon';
        themeToggle.innerHTML = '<i class="bx bx-moon"></i>';
        themeToggle.title = 'Toggle Theme';
        
        themeToggle.addEventListener('click', function() {
            const icon = this.querySelector('i');
            if (icon.classList.contains('bx-moon')) {
                icon.classList.remove('bx-moon');
                icon.classList.add('bx-sun');
                document.body.classList.add('light-theme');
                showToast('Light theme activated', 'info');
            } else {
                icon.classList.remove('bx-sun');
                icon.classList.add('bx-moon');
                document.body.classList.remove('light-theme');
                showToast('Dark theme activated', 'info');
            }
        });
        
        // Add theme toggle to header
        document.querySelector('.header-actions').appendChild(themeToggle);
        
        // Add light theme styles
        const lightThemeStyle = document.createElement('style');
        lightThemeStyle.textContent = `
            body.light-theme {
                --primary-dark: #f8fafc;
                --secondary-dark: #f1f5f9;
                --text-primary: #0f172a;
                --text-secondary: #475569;
                --text-muted: #64748b;
                --card-bg: rgba(255, 255, 255, 0.9);
                --glass-bg: rgba(0, 0, 0, 0.05);
                --glass-border: rgba(0, 0, 0, 0.1);
            }
            
            body.light-theme .sidebar-premium {
                background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
                border-right: 1px solid #e2e8f0;
            }
            
            body.light-theme .nav-link-premium {
                color: #64748b;
            }
            
            body.light-theme .nav-link-premium:hover {
                background: rgba(37, 99, 235, 0.1);
                color: #2563eb;
            }
            
            body.light-theme .nav-link-premium.active {
                color: white;
            }
            
            body.light-theme ::-webkit-scrollbar-track {
                background: #f1f5f9;
            }
        `;
        document.head.appendChild(lightThemeStyle);
        
        // Initialize with animations
        document.addEventListener('DOMContentLoaded', function() {
            // Animate stats on load
            document.querySelectorAll('.stat-card-premium').forEach((card, index) => {
                setTimeout(() => {
                    card.classList.add('animated');
                }, index * 100);
            });
            
            // Show welcome message
            setTimeout(() => {
                showToast('Welcome to NULL7 Automatic List Tools!', 'success');
            }, 1000);
        });
    </script>
</body>
</html>