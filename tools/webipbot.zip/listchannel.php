<?php
ini_set("display_error", 0);
session_start();

if (!isset($_SESSION["user"]) && !isset($_SESSION["pass"])) {
    header("Location: index.php");
    exit();
}

$username = isset($_SESSION["user"]) ? $_SESSION["user"] : "Admin";

// Fungsi-fungsi tetap sama
function LoadConfig() {
    $jsonFilePath = "config.json";
    $jsonData = file_get_contents($jsonFilePath);
    $dataArray = json_decode($jsonData, true);

    if ($dataArray === null && json_last_error() !== JSON_ERROR_NONE) {
        return [];
    } else {
        return $dataArray;
    }
}

function addListChannel($link) {
    $jsonFilePath = "config.json";
    $jsonData = file_get_contents($jsonFilePath);
    $dataArray = json_decode($jsonData, true);

    if ($dataArray === null && json_last_error() !== JSON_ERROR_NONE) {
        return false;
    } else {
        $newString = $link;
        $dataArray["channel"][] = $newString;

        $updatedJsonData = json_encode($dataArray, JSON_PRETTY_PRINT);

        if (file_put_contents($jsonFilePath, $updatedJsonData) !== false) {
            return true;
        } else {
            return false;
        }
    }
}

function deleteListChannel($link) {
    $jsonFilePath = "config.json";
    $jsonString = file_get_contents($jsonFilePath);

    $data = json_decode($jsonString, true);

    $channelIndex = array_search($link, $data["channel"]);
    if ($channelIndex !== false) {
        unset($data["channel"][$channelIndex]);
        $data["channel"] = array_values($data["channel"]);
    }

    $newJsonString = json_encode($data, JSON_PRETTY_PRINT);
    file_put_contents($jsonFilePath, $newJsonString);
    return true;
}

function stringContainsInArray($needle, $haystack) {
    foreach ($haystack as $str) {
        if (strpos($str, $needle) !== false) {
            return true;
        }
    }
    return false;
}

$message = "";
$message_type = "";

if (isset($_POST["tambah"])) {
    $conf = LoadConfig()["channel"];
    
    if (stringContainsInArray($_POST["link"], $conf)) {
        $message = "Link sudah ada di database!";
        $message_type = "warning";
    } else {
        if (addListChannel($_POST["link"])) {
            $message = "Channel berhasil ditambahkan!";
            $message_type = "success";
        } else {
            $message = "Gagal menambahkan channel!";
            $message_type = "danger";
        }
    }
}

if (isset($_POST["hapus"])) {
    $link = $_POST["link"];
    $conf = LoadConfig()["channel"];

    if (!stringContainsInArray($link, $conf)) {
        $message = "Tidak ada link '$link' di database!";
        $message_type = "warning";
    } else {
        if (deleteListChannel($link)) {
            $message = "Channel berhasil dihapus!";
            $message_type = "success";
        } else {
            $message = "Gagal menghapus channel!";
            $message_type = "danger";
        }
    }
}

$conf = LoadConfig()["channel"];
$total_channels = count($conf);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NULL7 AUTOMATIC LIST TOOLS | Channel Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel='stylesheet'>
    <link rel="stylesheet" href="assets/dashboard-premium.css">
    <style>
        /* Additional styles for list channel page */
        .channel-table-container {
            background: var(--card-bg);
            border-radius: 18px;
            border: 1px solid var(--glass-border);
            overflow: hidden;
        }
        
        .channel-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .channel-table thead {
            background: rgba(37, 99, 235, 0.1);
        }
        
        .channel-table th {
            padding: 18px 20px;
            text-align: left;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .channel-table td {
            padding: 16px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            vertical-align: middle;
        }
        
        .channel-table tbody tr:hover {
            background: rgba(37, 99, 235, 0.05);
        }
        
        .channel-number {
            width: 60px;
            font-weight: 700;
            color: var(--accent-blue);
        }
        
        .channel-link {
            word-break: break-all;
            font-family: 'Monaco', 'Courier New', monospace;
            font-size: 13px;
        }
        
        .channel-actions {
            width: 100px;
            text-align: center;
        }
        
        .channel-badge {
            display: inline-block;
            padding: 4px 12px;
            background: rgba(37, 99, 235, 0.1);
            color: var(--accent-blue);
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
        }
        
        .form-card {
            background: var(--card-bg);
            border-radius: 18px;
            padding: 25px;
            border: 1px solid var(--glass-border);
            margin-bottom: 25px;
        }
        
        .form-title {
            color: var(--text-primary);
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-title i {
            color: var(--accent-blue);
        }
        
        .form-group-premium {
            margin-bottom: 20px;
        }
        
        .form-label-premium {
            color: var(--text-secondary);
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
        }
        
        .form-input-premium {
            width: 100%;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            padding: 14px 18px;
            color: var(--text-primary);
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .form-input-premium:focus {
            outline: none;
            border-color: var(--accent-blue);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        
        .btn-group-premium {
            display: flex;
            gap: 12px;
        }
        
        .btn-add {
            background: linear-gradient(135deg, #10b981, #059669);
            border: none;
            color: white;
            padding: 14px 28px;
            border-radius: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-add:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
        }
        
        .btn-delete {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            border: none;
            color: white;
            padding: 14px 28px;
            border-radius: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        
        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.3);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }
        
        .empty-icon {
            width: 80px;
            height: 80px;
            background: rgba(37, 99, 235, 0.1);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: var(--accent-blue);
            font-size: 36px;
        }
        
        .empty-title {
            color: var(--text-primary);
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .empty-description {
            color: var(--text-muted);
            font-size: 14px;
            max-width: 400px;
            margin: 0 auto;
        }
        
        .stat-card-channel {
            background: var(--card-bg);
            border-radius: 18px;
            padding: 25px;
            border: 1px solid var(--glass-border);
            text-align: center;
        }
        
        .channel-count {
            font-size: 42px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
        }
        
        .channel-label {
            color: var(--text-muted);
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        @media (max-width: 768px) {
            .channel-table {
                display: block;
                overflow-x: auto;
            }
            
            .btn-group-premium {
                flex-direction: column;
            }
            
            .btn-add, .btn-delete {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="mobile-menu-toggle" id="mobileMenuToggle">
        <i class='bx bx-menu'></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar-premium" id="sidebar">
        <div class="brand-section">
            <div class="brand-logo">
                <div class="logo-icon">
                    <i class='bx bx-code-alt'></i>
                </div>
                <div class="brand-text">
                    <h2>NULL7</h2>
                    <p>AUTOMATIC LIST TOOLS</p>
                </div>
            </div>
        </div>

        <!-- Navigation Menu -->
        <ul class="nav-menu-premium">
            <li class="nav-item-premium">
                <a href="dashboard.php" class="nav-link-premium">
                    <i class='bx bx-home nav-icon'></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="listchannel.php" class="nav-link-premium active">
                    <i class='bx bx-list-ul nav-icon'></i>
                    <span class="nav-text">List Channels</span>
                    <span class="nav-badge"><?php echo $total_channels; ?></span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="listfile.php" class="nav-link-premium">
                    <i class='bx bx-folder nav-icon'></i>
                    <span class="nav-text">Results</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="#" class="nav-link-premium">
                    <i class='bx bx-bar-chart nav-icon'></i>
                    <span class="nav-text">Analytics</span>
                </a>
            </li>
            <li class="nav-item-premium">
                <a href="logout.php" class="nav-link-premium">
                    <i class='bx bx-log-out nav-icon'></i>
                    <span class="nav-text">Logout</span>
                </a>
            </li>
        </ul>

        <!-- User Profile -->
        <div class="user-profile-premium">
            <div class="d-flex align-items-center">
                <div class="user-avatar-large">
                    <?php echo strtoupper(substr($username, 0, 1)); ?>
                </div>
                <div class="user-info-premium">
                    <h4><?php echo htmlspecialchars($username); ?></h4>
                    <p>Channel Manager</p>
                    <div class="user-status">
                        <span class="status-indicator"></span>
                        <span class="text-success fw-bold">Online</span>
                    </div>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content-premium" id="mainContent">
        <!-- Header -->
        <header class="header-premium fade-in-up">
            <div class="welcome-section-premium">
                <h1>Channel Management</h1>
                <p>Manage your list channels in one place</p>
            </div>
            <div class="header-actions">
                <div class="search-container-premium">
                    <i class='bx bx-search search-icon-premium'></i>
                    <input type="text" class="search-input-premium" placeholder="Search channels..." id="searchInput">
                </div>
                <button class="action-btn-icon" title="Export Channels" id="exportBtn">
                    <i class='bx bx-export'></i>
                </button>
                <button class="action-btn-icon" title="Refresh List" id="refreshBtn">
                    <i class='bx bx-refresh'></i>
                </button>
            </div>
        </header>

        <!-- Stats Card -->
        <div class="stats-grid-premium">
            <div class="stat-card-channel fade-in-up">
                <div class="channel-count"><?php echo $total_channels; ?></div>
                <div class="channel-label">Total Channels</div>
                <div class="mt-3">
                    <span class="channel-badge">Active</span>
                </div>
            </div>
        </div>

        <!-- Message Alert -->
        <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show fade-in-up" 
             role="alert" style="border-radius: 12px; border: none; margin-bottom: 25px;">
            <div class="d-flex align-items-center">
                <i class='bx <?php 
                    echo $message_type == 'success' ? 'bx-check-circle' : 
                         ($message_type == 'warning' ? 'bx-error-circle' : 'bx-x-circle'); 
                ?> me-2' style="font-size: 20px;"></i>
                <span><?php echo htmlspecialchars($message); ?></span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <!-- Add/Delete Forms -->
        <div class="row fade-in-up" style="animation-delay: 0.1s">
            <div class="col-lg-6 mb-4">
                <div class="form-card">
                    <div class="form-title">
                        <i class='bx bx-plus-circle'></i>
                        <span>Add New Channel</span>
                    </div>
                    <form method="POST" id="addForm">
                        <div class="form-group-premium">
                            <label class="form-label-premium">Channel Link</label>
                            <input type="text" name="link" class="form-input-premium" 
                                   placeholder="Enter channel link (e.g., https://t.me/...)" required>
                        </div>
                        <div class="btn-group-premium">
                            <button type="submit" name="tambah" class="btn-add">
                                <i class='bx bx-plus'></i> Add Channel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="col-lg-6 mb-4">
                <div class="form-card">
                    <div class="form-title">
                        <i class='bx bx-trash'></i>
                        <span>Delete Channel</span>
                    </div>
                    <form method="POST" id="deleteForm">
                        <div class="form-group-premium">
                            <label class="form-label-premium">Channel Link</label>
                            <input type="text" name="link" class="form-input-premium" 
                                   placeholder="Enter exact channel link to delete" required>
                        </div>
                        <div class="btn-group-premium">
                            <button type="submit" name="hapus" class="btn-delete">
                                <i class='bx bx-trash'></i> Delete Channel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Channels List -->
        <div class="channel-table-container fade-in-up" style="animation-delay: 0.2s">
            <div class="p-4 border-bottom border-secondary">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="text-white mb-0">📋 Channel List</h5>
                    <span class="text-muted">Showing <?php echo $total_channels; ?> channels</span>
                </div>
            </div>
            
            <?php if ($total_channels > 0): ?>
            <div class="table-responsive">
                <table class="channel-table">
                    <thead>
                        <tr>
                            <th class="channel-number">#</th>
                            <th>Channel Link</th>
                            <th class="channel-actions">Status</th>
                        </tr>
                    </thead>
                    <tbody id="channelsTable">
                        <?php foreach ($conf as $index => $channel): ?>
                        <tr class="channel-row">
                            <td class="channel-number"><?php echo $index + 1; ?></td>
                            <td class="channel-link"><?php echo htmlspecialchars($channel); ?></td>
                            <td class="channel-actions">
                                <span class="badge bg-success">Active</span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon">
                    <i class='bx bx-list-ul'></i>
                </div>
                <div class="empty-title">No Channels Found</div>
                <div class="empty-description">
                    You haven't added any channels yet. Use the form above to add your first channel.
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($total_channels > 0): ?>
            <div class="p-4 border-top border-secondary">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="text-muted">
                        <i class='bx bx-info-circle'></i>
                        Total: <?php echo $total_channels; ?> channels
                    </div>
                    <div>
                        <button class="btn btn-sm btn-outline-primary me-2" id="copyAllBtn">
                            <i class='bx bx-copy'></i> Copy All
                        </button>
                        <button class="btn btn-sm btn-outline-success" id="exportJsonBtn">
                            <i class='bx bx-download'></i> Export JSON
                        </button>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <footer class="footer-premium mt-4">
            <div class="copyright">
                <div class="d-flex align-items-center justify-content-center mb-2">
                    <strong>NULL7 AUTOMATIC LIST TOOLS</strong>
                    <span class="version-badge">Channel Manager</span>
                </div>
                <div class="text-muted">
                    <i class='bx bx-time'></i> Last updated: <span id="currentTime"><?php echo date("H:i"); ?></span> | 
                    <i class='bx bx-user'></i> User: <?php echo htmlspecialchars($username); ?> | 
                    <i class='bx bx-data'></i> Channels: <?php echo $total_channels; ?>
                </div>
                <div class="mt-2">
                    <pre class="mb-0" style="color: var(--text-muted); font-size: 0.7rem;">© 2024 NULL7 Tools | X - MrG3P5 | 2K24</pre>
                </div>
            </div>
        </footer>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mobile Menu Toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        
        mobileMenuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('mobile-open');
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth < 992 && 
                !sidebar.contains(e.target) && 
                !mobileMenuToggle.contains(e.target)) {
                sidebar.classList.remove('mobile-open');
            }
        });
        
        // Update current time
        function updateTime() {
            const currentTimeEl = document.getElementById('currentTime');
            if (currentTimeEl) {
                const now = new Date();
                currentTimeEl.textContent = now.toLocaleTimeString('en-US', { 
                    hour12: false,
                    hour: '2-digit',
                    minute: '2-digit'
                });
            }
        }
        
        setInterval(updateTime, 1000);
        
        // Search functionality
        const searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('.channel-row');
            
            rows.forEach(row => {
                const channelLink = row.querySelector('.channel-link').textContent.toLowerCase();
                if (channelLink.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
        
        // Export buttons functionality
        document.getElementById('exportBtn').addEventListener('click', function() {
            this.innerHTML = '<i class="bx bx-loader-circle bx-spin"></i>';
            this.disabled = true;
            
            setTimeout(() => {
                this.innerHTML = '<i class="bx bx-export"></i>';
                this.disabled = false;
                showToast('Channels exported successfully!', 'success');
            }, 1000);
        });
        
        document.getElementById('refreshBtn').addEventListener('click', function() {
            this.classList.add('bx-spin');
            setTimeout(() => {
                location.reload();
            }, 500);
        });
        
        // Copy all channels
        document.getElementById('copyAllBtn')?.addEventListener('click', function() {
            const channels = <?php echo json_encode($conf); ?>;
            const channelsText = channels.join('\n');
            
            navigator.clipboard.writeText(channelsText).then(() => {
                showToast('All channels copied to clipboard!', 'success');
            }).catch(err => {
                console.error('Failed to copy: ', err);
                showToast('Failed to copy channels', 'danger');
            });
        });
        
        // Export JSON
        document.getElementById('exportJsonBtn')?.addEventListener('click', function() {
            const channels = <?php echo json_encode($conf); ?>;
            const dataStr = JSON.stringify({ channel: channels }, null, 2);
            const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
            
            const exportFileDefaultName = 'channels_' + new Date().toISOString().slice(0,10) + '.json';
            
            const linkElement = document.createElement('a');
            linkElement.setAttribute('href', dataUri);
            linkElement.setAttribute('download', exportFileDefaultName);
            linkElement.click();
            
            showToast('JSON file downloaded!', 'success');
        });
        
        // Form validation
        document.getElementById('addForm').addEventListener('submit', function(e) {
            const linkInput = this.querySelector('input[name="link"]');
            const link = linkInput.value.trim();
            
            if (!link) {
                e.preventDefault();
                showToast('Please enter a channel link', 'warning');
                linkInput.focus();
                return;
            }
            
            // Simple URL validation
            if (!link.includes('://')) {
                if (!confirm('The link doesn\'t look like a valid URL. Continue anyway?')) {
                    e.preventDefault();
                    return;
                }
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="bx bx-loader-circle bx-spin"></i> Adding...';
            submitBtn.disabled = true;
            
            // Re-enable after 3 seconds (in case of error)
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 3000);
        });
        
        document.getElementById('deleteForm').addEventListener('submit', function(e) {
            const linkInput = this.querySelector('input[name="link"]');
            const link = linkInput.value.trim();
            
            if (!link) {
                e.preventDefault();
                showToast('Please enter a channel link to delete', 'warning');
                linkInput.focus();
                return;
            }
            
            if (!confirm('Are you sure you want to delete this channel?\n\n' + link)) {
                e.preventDefault();
                return;
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="bx bx-loader-circle bx-spin"></i> Deleting...';
            submitBtn.disabled = true;
            
            // Re-enable after 3 seconds (in case of error)
            setTimeout(() => {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }, 3000);
        });
        
        // Toast notification function
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast-notification toast-${type}`;
            toast.innerHTML = `
                <div class="toast-icon">
                    <i class='bx bx-${type === 'success' ? 'check-circle' : type === 'warning' ? 'error-circle' : 'info-circle'}'></i>
                </div>
                <div class="toast-message">${message}</div>
                <button class="toast-close"><i class='bx bx-x'></i></button>
            `;
            
            // Add styles
            toast.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#10b981' : type === 'warning' ? '#f59e0b' : '#3b82f6'};
                color: white;
                padding: 15px 20px;
                border-radius: 10px;
                display: flex;
                align-items: center;
                gap: 12px;
                z-index: 9999;
                animation: slideIn 0.3s ease;
                max-width: 400px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            `;
            
            document.body.appendChild(toast);
            
            // Close button
            toast.querySelector('.toast-close').addEventListener('click', () => {
                toast.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => toast.remove(), 300);
            });
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.style.animation = 'slideOut 0.3s ease';
                    setTimeout(() => toast.remove(), 300);
                }
            }, 5000);
        }
        
        // Add animation styles for toast
        const toastStyle = document.createElement('style');
        toastStyle.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
            
            .toast-notification .toast-icon {
                font-size: 20px;
            }
            
            .toast-notification .toast-message {
                flex: 1;
                font-size: 14px;
            }
            
            .toast-notification .toast-close {
                background: none;
                border: none;
                color: white;
                cursor: pointer;
                font-size: 18px;
                padding: 0;
            }
        `;
        document.head.appendChild(toastStyle);
        
        // Add click animation to channel rows
        document.querySelectorAll('.channel-row').forEach(row => {
            row.addEventListener('click', function() {
                const channelLink = this.querySelector('.channel-link').textContent;
                navigator.clipboard.writeText(channelLink).then(() => {
                    // Visual feedback
                    this.style.backgroundColor = 'rgba(37, 99, 235, 0.1)';
                    setTimeout(() => {
                        this.style.backgroundColor = '';
                    }, 500);
                    
                    showToast('Channel link copied to clipboard!', 'success');
                });
            });
            
            // Hover effect
            row.addEventListener('mouseenter', function() {
                this.style.cursor = 'pointer';
            });
        });
        
        // Theme toggle (consistent with dashboard)
        const themeToggle = document.createElement('button');
        themeToggle.className = 'action-btn-icon';
        themeToggle.innerHTML = '<i class="bx bx-moon"></i>';
        themeToggle.title = 'Toggle Theme';
        
        themeToggle.addEventListener('click', function() {
            const icon = this.querySelector('i');
            if (icon.classList.contains('bx-moon')) {
                icon.classList.remove('bx-moon');
                icon.classList.add('bx-sun');
                document.body.classList.add('light-theme');
                showToast('Light theme activated', 'info');
            } else {
                icon.classList.remove('bx-sun');
                icon.classList.add('bx-moon');
                document.body.classList.remove('light-theme');
                showToast('Dark theme activated', 'info');
            }
        });
        
        // Add theme toggle to header
        document.querySelector('.header-actions').appendChild(themeToggle);
        
        // Light theme styles
        const lightThemeStyle = document.createElement('style');
        lightThemeStyle.textContent = `
            body.light-theme .channel-table-container,
            body.light-theme .form-card,
            body.light-theme .stat-card-channel {
                background: rgba(255, 255, 255, 0.9);
                border-color: rgba(0, 0, 0, 0.1);
            }
            
            body.light-theme .channel-table th {
                color: #475569;
                border-color: rgba(0, 0, 0, 0.1);
            }
            
            body.light-theme .channel-table td {
                border-color: rgba(0, 0, 0, 0.05);
            }
            
            body.light-theme .form-input-premium {
                background: rgba(0, 0, 0, 0.05);
                border-color: rgba(0, 0, 0, 0.1);
                color: #0f172a;
            }
            
            body.light-theme .empty-description {
                color: #64748b;
            }
        `;
        document.head.appendChild(lightThemeStyle);
        
        // Initialize with animations
        document.addEventListener('DOMContentLoaded', function() {
            // Animate elements on load
            const animatedElements = document.querySelectorAll('.fade-in-up');
            animatedElements.forEach((el, index) => {
                setTimeout(() => {
                    el.style.opacity = '1';
                    el.style.transform = 'translateY(0)';
                }, index * 100);
            });
            
            // Set initial styles for animation
            animatedElements.forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            });
        });
    </script>
</body>
</html>