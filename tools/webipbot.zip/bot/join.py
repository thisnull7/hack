import re
import os
import sys
import json
import asyncio
from telethon import TelegramClient, events
from telethon.tl.functions.channels import JoinChannelRequest

API_ID = 8955549
HASH_ID = "61fa8cef693be5bf28dce07f473d030d"

client = TelegramClient('x', API_ID, HASH_ID)

with open("../config.json", "r") as file:
    myChannelIDList = json.load(file)["channel"]
chan = myChannelIDList

async def main():
    for ch in chan:
        try:
            await client(JoinChannelRequest(ch))
            print("[DONE] " + ch)
        except Exception as e:
            print("[FAIL] " + ch)

with client:
    client.loop.run_until_complete(main())
