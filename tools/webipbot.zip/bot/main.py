import re
import os
import json
from telethon import TelegramClient, events

API_ID = 148856848
HASH_ID = "f0fb3c51c7329a915ccbc7168c2b9624"

client = TelegramClient('x', API_ID, HASH_ID)
with open("../config.json", "r") as file:
    myChannelIDList = json.load(file)["channel"]

@client.on(events.NewMessage(chats=myChannelIDList))
async def my_event_handler(event):
    try:
        if event.message.media:
            filenames = re.findall(r"file_name='(.*?)'", str(event.message.media))[0]
            mimeTypes = re.findall(r"mime_type='(.*?)'", str(event.message.media))[0]
            
            if mimeTypes == "text/plain":
                files = await client.download_media(event.message.media, "list/")
                os.system("go run main.go")
    except:
        pass

client.start()
client.run_until_disconnected()
