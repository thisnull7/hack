<?php

    ini_set("display_error", 0);

    session_start();
    session_destroy();

    header("Location: index.php");

?>